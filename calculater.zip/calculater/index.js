
function add(){

    let a=document.getElementById("value1").Value;
    let b=document.getElementById("value2").Value;
   
    document.getElementById("result").Value=parseInt(a)+parseInt(b);
    
    document.getElementById("value1").style.backgroundColor="lightblue"
    document.getElementById("value2").style.backgroundColor="lightblue"
    document.getElementById("result").style.backgroundColor="lightblue"
    }
    
    document.getElementById("add").addEventListener("click",add);


    function sub(){

        let a=parseInt(document.getElementById("value1").Value);
        let b=parseInt(document.getElementById("value2").Value);
        let sub=a-b;
        document.getElementById("result").Value=sub;
        
        document.getElementById("value1").style.backgroundColor="yellow"
        document.getElementById("value2").style.backgroundColor="yellow"
        document.getElementById("result").style.backgroundColor="yellow"
        }
        
        document.getElementById("sub").addEventListener("click",sub);


        function mul(){

            let a=parseInt(document.getElementById("value1").Value);
            let b=parseInt(document.getElementById("value2").Value);
            let mul=a*b;
            document.getElementById("result").Value=mul;

            document.getElementById("value1").style.backgroundColor="pink"
            document.getElementById("value2").style.backgroundColor="pink"
            document.getElementById("result").style.backgroundColor="pink"
            
            }
            
            document.getElementById("mul").addEventListener("click",mul);


            function div(){

                let a=parseInt(document.getElementById("value1").Value);
                let b=parseInt(document.getElementById("value2").Value);
                let div=a/b;
                document.getElementById("result").Value=div;
                 
                document.getElementById("value1").style.backgroundColor="lightgrey"
                document.getElementById("value2").style.backgroundColor="lightgrey"
                document.getElementById("result").style.backgroundColor="lightgrey"
                
                }
                
                document.getElementById("div").addEventListener("click",div);



                function exp(){

                    let a=parseInt(document.getElementById("value1").Value);
                    let b=parseInt(document.getElementById("value2").Value);
                    let exp=a**b;
                    document.getElementById("result").Value=exp;
                    
                    document.getElementById("value1").style.backgroundColor="lightgreen"
                    document.getElementById("value2").style.backgroundColor="lightgreen"
                    document.getElementById("result").style.backgroundColor="lightgreen"
                    }
                    
                    document.getElementById("exp").addEventListener("click",exp);

                