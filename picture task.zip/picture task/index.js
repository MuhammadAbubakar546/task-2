function NAYAPAKISTAN(){

let img= document.getElementById("tabdeeli");
let i= img.getAttribute("src");
n= "./download (1).jpg";
img.setAttribute("src",n);

let a=document.getElementById("heading");
a.innerText="NAYA PAKISTAN";
a.style.color="green"
}
document.getElementById("next").addEventListener("click",NAYAPAKISTAN)




function PURANAPAKISTAN(){

    let img= document.getElementById("tabdeeli");
    let i= img.getAttribute("src");
    n= "./images (1).jpg";
    img.setAttribute("src",n);

    let b=document.getElementById("heading") ;
    b.innerText="PURANA PAKISTAN";
    b.style.color="blue";
    }
    document.getElementById("PREVIOUS").addEventListener("click",PURANAPAKISTAN)